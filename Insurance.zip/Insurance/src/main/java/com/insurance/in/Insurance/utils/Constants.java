package com.insurance.in.Insurance.utils;

public class Constants {

	public static final String role_user="ROLE_USER";
	
	public static final String role_admin = "ROLE_ADMIN";
}
